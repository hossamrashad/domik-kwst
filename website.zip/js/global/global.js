function scrollUp(l){let s=document.getElementById("scroll-up");l.preventDefault(),560<=this.scrollY?s.classList.add("show-scroll"):s.classList.remove("show-scroll")}window.addEventListener("scroll",scrollUp);
//# sourceMappingURL=global.js.map
